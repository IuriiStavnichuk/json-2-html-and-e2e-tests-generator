angular.module('App', ['calendee.valOnTimeout']).
    controller('ValidationController', [ '$scope', function($scope){

        $scope.user = {};
    }]) ;